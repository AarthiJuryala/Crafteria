<?php
include "config.php";
if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($con,$_POST['email']);
    $password = mysqli_real_escape_string($con,$_POST['password']);

    if ($email != "" && $password != ""){
        $sql_query = "select count(*) as count from craftsman where email='".$email."' and password='".$password."'";
        $result = mysqli_query($con,$sql_query);
        $row = mysqli_fetch_array($result);
        $count = $row['count'];
        echo $count;
        if($count==1){
            $_SESSION['email'] = $email;
            header('Location: home.php');
        }else{
            echo "Invalid username and password";
        }

    }

}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crafteria</title>
    <!---<link rel="stylesheet" href="style.css">-->
    <link rel="stylesheet" href="styleheader.css">   
</head>
<style>
    body{
    margin: 0;
    padding: 0;
    background: url('images/channapatna.png');
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
}
.login-box{
    margin-top:50px;
    width: 320px;
    height: 420px;
    font-family:  Cascadia Code;
    /*font-family:  Jazz LET, fantasy;*/
    top: 50%;
    left: 50%;
    position: absolute;
    background-color: rgba(255,255,255,0.3);
    border-radius: 6px;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
}

h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 32px;
    font-family: 'Papyrus';
    color:#fff;
}
::placeholder{
    color:grey;
}
.login-box p{
    margin: 0;
    padding: 0;
    font-weight: bold;
}
.login-box input{
    width: 100%;
    margin-bottom: 20px;
}
.login-box input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 40px;
    font-size: 16px;
}
.login-box input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background: black;
    color: white;
    font-size: 18px;
    border-radius: 20px;
}
.login-box input[type="submit"]:hover
{
    cursor: pointer;
    background: red;
    color: white;
}

.login-box a{
    text-decoration: none;
    font-size: 16px;
    color: black;
}
.login-box a:hover
{
    color: white;
}
</style>

    <body>

    <div class="box-area">
		<header>
			<div class="wrapper">
				<div class="logo">
					<a href="#">Crafteria</a>
				</div>
				<nav>
					<a href="home.php">Home</a> 
                    <a href="about1.html">About</a>
					<a href="products.php">Products</a> 
                    <a href="training.php">Get Trained</a> 
                    <a href="testimonials.html">Feedback</a>  
				</nav>
			</div>
		</header>
		<!---<div class="banner-area">
			<h2>Want to know more?</h2>
		</div>-->
	</div>

    <div class="login-box">
        <h1>Craftsman Login</h1>
            <form action="" method="post">
            <p>Email Id</p>
            <input type="text" name="email" placeholder="Enter Email Id">
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password">
            <input type="submit" name="login" value="login">
            <div style="text-align:center">
            <!---<a href="#">Forget Password</a><br><br> --->
            <a href="craftsignup.php">Create an account</a><br></br>
            <a href="index.php">Are you a Customer?</a>  
        </div> 
            </form>
        
        
        </div>
    
    </body>
</html>