<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "crafteria";

$conn = mysqli_connect($server,$username,$password,$dbname);
if(isset($_POST["submit"]))
{
  if((!empty($_POST['name'])) && (!empty($_POST['email'])) && (!empty($_POST['address'])) && (!empty($_POST['contact'])) && (!empty($_POST['password'])) )
  {
     $name = $_POST['name'];
     $email = $_POST['email'];
     $address = $_POST['address'];
     $contact = $_POST['contact'];
     $password = $_POST['password'];
     $query = "INSERT INTO customer(name,email,address,contact,password) VALUES('$name','$email','$address','$contact','$password')";
     echo "B";
       $run = mysqli_query($conn,$query) or die(mysqli_error($conn));
       echo "c";

       if($run){
        echo "Form submitted succesfully.";

       }
       else{

        echo "Form not submitted."; 
       }

    }
    else{
      echo "all fields required.";
    }

}