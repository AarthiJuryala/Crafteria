<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "crafteria");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

    $price = mysqli_real_escape_string($db, $_POST['price']);

    $name = mysqli_real_escape_string($db, $_POST['name']);

    $email = mysqli_real_escape_string($db, $_POST['email']);

  	// image file directory
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO images (image, image_text, price, name, email) VALUES ('$image', '$image_text', '$price', '$name', '$email')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crafteria</title>
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="stylesheet" href="styleheader.css">

<style type="text/css">
   #content{
   	width: 50%;
   	margin: 20px auto;
    margin-top:0px;
    padding-top:100px;
   	border: 1px solid #cbcbcb;
   }
   form{
   	width: 50%;
   	margin: 20px auto;
   }
   form div{
   	margin-top: 5px;
   }
   #img_div{
   	width: 80%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }
</style>
</head>
<body>

<div class="box-area">
		<header>
			<div class="wrapper">
				<div class="logo">
					<a href="#">Crafteria</a>
				</div>
				<nav>
					<a href="home.php">Home</a> 
          <a href="about1.html">About</a>
					<a href="products.php">Products</a> 
          <a href="training.php">Get Trained</a> 
          <a href="testimonials.html">Feedback</a>  
				</nav>
			</div>
		</header>
		
	</div>

<div id="content">
  


<div class="upload-form">
    <h2>Your Product</h2> 
  <form method="POST" action="products.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
  	  <input type="file" name="image">
  	</div>
    
  	<div>
      <textarea 
      	id="text" 
        class="text-field"
       	 
      	name="image_text" 
      	placeholder="Describe the product..."></textarea>
  	</div>

    <div>
        <input type="text" name="price" id="price" class="input-field" placeholder="Price...">
    </div>

    <div>
        <input type="text" name="name" id="name" class="input-field" placeholder="Designer Name...">
    </div>

    <div>
        <input type="email" name="email" id="email" class="input-field" placeholder="Email...">
    </div>

  	<div>
  		<button class="btn" type="submit" name="upload">POST</button>
  	</div>

  </form>
</div>



</div>

<style>
    body{
        background-image: url('images/productbackground.png');
        background-repeat: no-repeat;
        background-size: cover;

    }

    #content{
        width : 80%;
    }

    .product-box{
        width : 80%; 
    }

    #img_div{
        /*width:40%;
        float: left;*/
    }

    .upload-form{
        padding: 20px;
    }


    form{
    margin: 35px;
}

.input-field{
    width: 300px;
    height: 30px;
    margin-top: 10px;
    padding-left: 10px;
    padding-right: 10px;
    border: 1px solid #777;
    border-radius: 10px;
    outline: none;
}
.text-field{
    height: 70px;
    width: 300px;
    padding-top: 10px;
    border-radius:10px;
}
.btn{
    border-radius: 10px;
    color: black;
    margin-top: 10px;
    padding: 10px;
    background-color: #eecccc;
    font-size: 12px;
    border: none;
    cursor: pointer;
    width: 70px;
    margin-bottom: 20px;
}
.btn:hover{
    background-color: black;
    color: #eecccc;
}
</style>
</body>
</html>