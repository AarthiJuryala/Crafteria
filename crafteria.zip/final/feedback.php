<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="feed.css">
    <link rel="stylesheet" href="styleheader.css">
    <title>Crafteria</title>
</head>
<body>
    <div class="box-area">
		<header>
			<div class="wrapper">
				<div class="logo">
					<a href="#">Crafteria</a>
				</div>
				<nav>
                    <a href="home.php">Home</a> 
                    <a href="about1.html">About</a>
					<a href="products.php">Products</a> 
                    <a href="training.php">Get Trained</a> 
                    <a href="testimonials.html">Feedback</a>  
				</nav>
			</div>
		</header>
		<div class="banner-area">
			<h2>Feedback</h2>
		</div>
	</div>

    
    <div class="contact-box">
		<form action="feedinsert.php" method="post">
            <h2>Feedback</h2>
            <input type="text" class="input-field" placeholder="Your Name..." name="name">
            <input type="email" class="input-field" placeholder="Your Email..." name="email">
            <textarea type="text" class="input-field textarea-field" placeholder="Your Message..." name="comments">
            </textarea>
            <button type="submit" class="btn" name="submit">Send Message</button>
		</form>
    </div>

    <style>
        .btn{
            text-align: center;
            background-color: #eecccc;
            color:black;
            padding: 6px;
            border: 1px black;
            border-radius: 30px;
            cursor: pointer;
            font-size: 20px;
        }

        .btn:hover{
            background-color: black;
            color: rgb(240, 238, 234);
        }

        body{
            background-image: url('images/productbackground.png');
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
    
	
</body>
</html>