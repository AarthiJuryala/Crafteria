<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "crafteria";

$conn = mysqli_connect($server,$username,$password,$dbname);
if(isset($_POST["submit"]))
{
  if((!empty($_POST['name'])) && (!empty($_POST['contact'])) && (!empty($_POST['email'])) && (!empty($_POST['craft'])) && (!empty($_POST['duration'])) && (!empty($_POST['days'])) )
  {
     $name = $_POST['name'];
     $contact = $_POST['contact'];
     $email = $_POST['email'];
     $craft = $_POST['craft'];
     $duration = $_POST['duration'];
     $days = $_POST['days'];
     $query = "INSERT INTO training(name,contact,email,craft,duration,days) VALUES('$name','$contact','$email','$craft','$duration','$days')";
     echo "B";
       $run = mysqli_query($conn,$query) or die(mysqli_error($conn));
       echo "c";

       if($run){
        echo "Form submitted succesfully.";

       }
       else{

        echo "Form not submitted."; 
       }

    }
    else{
      echo "all fields required.";
    }

}