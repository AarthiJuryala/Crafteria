<?php

session_start();

$server = "localhost";
$username = "root";
$password = "";
$dbname = "crafteria";
$con = mysqli_connect($server,$username,$password,$dbname);
// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
/*echo "connected";*/