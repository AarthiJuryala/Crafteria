<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crafteria</title>
    <link rel="stylesheet" href="styleheader.css">
    <link rel="stylesheet" type="text/css" href="regstyle.css">
    
</head>
<body>
    <div class="box-area">
		<header>
			<div class="wrapper">
				<div class="logo">
					<a href="#">Crafteria</a>
				</div>
				<nav>
					<a href="home.php">Home</a> 
                    <a href="about1.html">About</a>
					<a href="products.php">Products</a> 
                    <a href="training.php">Get Trained</a> 
                    <a href="testimonials.html">Feedback</a>  
				</nav>
			</div>
		</header>

	</div>

    <div class="signin">
        <form action="custinsert.php" method="post">
        <h2>Customer</h2>
        <input type="text" placeholder="Enter Username" name="name">
        <input type="email" placeholder="Enter Email" name="email">
        <input type="text" placeholder="Enter Address" name="address">
        <input type="text" placeholder="Enter Contact" name="contact">
        <input type="password" placeholder="Enter Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        <button class="btn" type="submit" name="submit">Sign Up</button>
        </form>
    </div>

    
</body>
</html>

