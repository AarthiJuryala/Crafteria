<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="styleheader.css">
    <title>Crafteria</title>
</head>
<body>
    <div class="box-area">
		<header>
			<div class="wrapper">
				<div class="logo">
					<a href="#">Crafteria</a>
				</div>
				<nav>
                    <a href="home.php">Home</a> 
                    <a href="about1.html">About</a>
					<a href="products.php">Products</a> 
                    <a href="training.php">Get Trained</a> 
                    <a href="testimonials.html">Feedback</a>  
				</nav>
			</div>
		</header>
		<div class="banner-area">
			<h2>Learn a New Skill!</h2>
		</div>
	</div>

    <div class="contact-box">
        <form action="traininsert.php" method="post">
            <h2>Register Here</h2>
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="input-field" placeholder="Your Name..." name="name">
            </div> 
            <div class="form-group">
                <label>Contact No.</label>
                <input type="text" class="input-field" placeholder="Your Contact Number..." name="contact">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="input-field" placeholder="Your Email..." name="email">
            </div>
            <div class="form-group">
                <label>Interested Craft</label>
                <input type="text" class="input-field" placeholder="Interested craft..." name="craft">
            </div>
            <div class="form-group">
                <label>Duration</label><br>
                <select id="duration" name="duration">
                    <option>10</option>
                    <option>15</option>
                    <option>30</option>
                </select>
            </div>
            <div class="form-group">
                <label>Days</label>
                <input type="text" class="input-field" placeholder="Available days in a week..." name="days">
            </div>
            <button type="submit" class="btn" name="submit">Submit</button>
        </form>
    </div>

    <style>
        .btn{
            text-align: center;
            background-color: #eecccc;
            color:black;
            padding: 6px;
            border: 1px black;
            border-radius: 30px;
            cursor: pointer;
            font-size: 20px;
        }

        .btn:hover{
            background-color: black;
            color: rgb(240, 238, 234);
        }

        body{
            background-image: url('images/productbackground.png');
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
    
	
</body>
</html>