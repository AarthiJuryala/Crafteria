<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "crafteria");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

    $price = mysqli_real_escape_string($db, $_POST['price']);

    $name = mysqli_real_escape_string($db, $_POST['name']);

    $email = mysqli_real_escape_string($db, $_POST['email']);

  	// image file directory
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO images (image, image_text, price, name, email) VALUES ('$image', '$image_text', '$price', '$name', '$email')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crafteria</title>
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="stylesheet" href="styleheader.css">

<style type="text/css">
   #content{
   	/*width: 50%;*/
   	margin: 20px auto;
    margin-top:0px;
    padding-top:100px;
   	border: 1px solid #cbcbcb;
   }
   
   #img_div{
   	width: 80%;
   	padding: 5px;
   	margin: 30px auto;
   	border: 2px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 160px;
   }
   p{
     font-size:20px;
     font-style:'Papyrus';
     padding:10px;
   }
</style>
</head>
<body>

<div class="box-area">
		<header>
			<div class="wrapper">
				<div class="logo">
					<a href="#">Crafteria</a>
				</div>
				<nav>
					<a href="home.php">Home</a> 
          <a href="about1.html">About</a>
					<a href="products.php">Products</a> 
          <a href="training.php">Get Trained</a> 
          <a href="testimonials.html">Feedback</a>  
				</nav>
			</div>
		</header>
	</div>

<div id="content">

    <div class="uploadbtn">
        <a href="upload.php" class="btn">Upload Your Product</a>
    </div>

    <style>
      .btn{
          text-align: left;
          background-color: #e78888;
          padding: 10px;
          border: 1px black;
          border-radius: 30px;
          cursor: pointer;
          font-size: 20px;
      }
      .uploadbtn a{
        padding-top:50px;
        margin-bottom: 20px;
        text-decoration: none;
        color: black;
      }
      .uploadbtn a:hover{
        background-color: black;
        color: blanchedalmond;
      }
    </style>
  


<div class = "product-box">
  <?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div id='img_div'>";
      	echo "<img src='images/".$row['image']."' >";
      	echo "<p>".$row['image_text']."</p>";
        echo "<p>".$row['price']."</p>";
        echo "<p>".$row['name']."</p>";
        echo "<p>".$row['email']."</p>";
      echo "</div>";
    }
  ?>
</div>

</div>

<style>
    body{
        background-image: url('images/productbackground.png');
        background-repeat: no-repeat;
        background-size: cover;

    }

    #content{
        width : 80%;
    }

    .product-box{
        width : 80%; 
    }

   
</style>
</body>
</html>